PryXploit Tools — Cordova project skeleton
Files included:
- www/index.html            (main web content)
- config.xml                (Cordova config)
- www/icon.png              (512x512 placeholder)

Cara membuat APK (Ringkasan):
1) Pasang Node.js dan Cordova:
   npm install -g cordova

2) Buat project Cordova (opsional) atau gunakan folder ini:
   cordova create PryXploitApp com.pryxploit.tools "PryXploit Tools"
   cd PryXploitApp

3) Salin folder 'www' dari paket ini ke folder project Cordova:
   rm -rf www
   cp -r path/to/unzipped/www ./www

4) Tambah platform Android:
   cordova platform add android

5) Build:
   cordova build android

Catatan:
- Anda butuh Android SDK / Java untuk build Android.
- Untuk mengganti ikon, ganti file www/icon.png dan update resources Android jika perlu.
- Jika mau otomatisasi build (APK online), diperlukan server dan kunci signing — demo ini tidak menyediakan itu.
